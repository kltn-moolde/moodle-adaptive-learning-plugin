<?php
defined('MOODLE_INTERNAL') || die();

$plugin->version   = 2025071700;       // Ngày tạo dạng yyyymmddxx
$plugin->requires  = 2022041900;       // Moodle tối thiểu (Moodle 4.0)
$plugin->component = 'local_userlog';  // Tên plugin