<?php
$string['pluginname'] = 'User Log';