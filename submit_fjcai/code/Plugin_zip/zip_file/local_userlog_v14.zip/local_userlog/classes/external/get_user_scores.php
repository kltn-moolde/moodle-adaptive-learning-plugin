<?php
namespace local_userlog\external;

defined('MOODLE_INTERNAL') || die();
require_once("$CFG->libdir/externallib.php");

use external_api;
use external_function_parameters;
use external_multiple_structure;
use external_single_structure;
use external_value;

class get_user_scores extends external_api
{

    public static function execute_parameters()
    {
        return new external_function_parameters([
            'userid' => new external_value(PARAM_INT, 'User ID'),
            'courseid' => new external_value(PARAM_INT, 'Course ID'),
            'sectionid' => new external_value(PARAM_INT, 'Section ID', VALUE_OPTIONAL)
        ]);
    }

    public static function execute($userid, $courseid, $sectionid = 0)
    {
        global $DB;

        self::validate_parameters(self::execute_parameters(), [
            'userid' => $userid,
            'courseid' => $courseid,
            'sectionid' => $sectionid
        ]);

        $params = [
            'userid1' => $userid, // cho qg.userid
            'userid2' => $userid, // cho qa.userid trong subquery
            'userid3' => $userid, // cho qa.userid trong JOIN
            'userid4' => $userid, // cho cmc.userid
            'courseid' => $courseid
        ];

        $section_filter = '';
        if ($sectionid > 0) {
            $section_filter = ' AND cm.section = :sectionid';
            $params['sectionid'] = $sectionid;
        }

        $sql = "
            SELECT 
                cm.id AS moduleid,
                q.id AS quizid,
                q.name AS activityname,
                'quiz' AS activitytype,
                COALESCE(qg.grade / gi.grademax, 0) AS score,
                COALESCE(qg.grade, 0) AS rawscore,
                gi.grademax AS maxscore,
                COALESCE(qa.max_attempt, 0) AS attempt,
                COALESCE(cmc.timemodified, 0) AS timecompleted
            FROM {course_modules} cm
            JOIN {modules} modn ON modn.id = cm.module
            JOIN {quiz} q ON q.id = cm.instance AND modn.name = 'quiz'
            LEFT JOIN {grade_items} gi ON gi.iteminstance = q.id AND gi.itemmodule = 'quiz'
            LEFT JOIN {quiz_grades} qg ON qg.quiz = q.id AND qg.userid = :userid1
            LEFT JOIN (
                SELECT quiz, userid, MAX(attempt) AS max_attempt
                FROM {quiz_attempts}
                WHERE userid = :userid2
                GROUP BY quiz, userid
            ) qa ON qa.quiz = q.id AND qa.userid = :userid3
            LEFT JOIN {course_modules_completion} cmc 
                ON cmc.coursemoduleid = cm.id AND cmc.userid = :userid4
            WHERE cm.course = :courseid
            AND modn.name = 'quiz'
            $section_filter
        ";

        $records = $DB->get_records_sql($sql, $params);
        $result = [];

        foreach ($records as $r) {
            $result[] = [
                'moduleid' => (int) $r->moduleid,
                'activityid' => (int) $r->quizid,
                'activityname' => $r->activityname,
                'activitytype' => $r->activitytype,
                'score' => (float) $r->score,
                'rawscore' => (float) $r->rawscore,
                'maxscore' => (float) $r->maxscore,
                'attempt' => (int) $r->attempt,
                'timecompleted' => (int) $r->timecompleted
            ];
        }

        return ['scores' => $result];
    }

    public static function execute_returns()
    {
        return new external_single_structure([
            'scores' => new external_multiple_structure(
                new external_single_structure([
                    'moduleid' => new external_value(PARAM_INT),
                    'activityid' => new external_value(PARAM_INT),
                    'activityname' => new external_value(PARAM_TEXT),
                    'activitytype' => new external_value(PARAM_TEXT),
                    'score' => new external_value(PARAM_FLOAT),
                    'rawscore' => new external_value(PARAM_FLOAT),
                    'maxscore' => new external_value(PARAM_FLOAT),
                    'attempt' => new external_value(PARAM_INT),
                    'timecompleted' => new external_value(PARAM_INT)
                ])
            )
        ]);
    }
}